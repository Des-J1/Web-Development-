
$("#heading1").on("click", function(){
$("#para1").slideDown(2100)
$("#para2").slideDown(3100)
$("#para3").slideDown(4100)
$("#para4").slideDown(5100)
})
